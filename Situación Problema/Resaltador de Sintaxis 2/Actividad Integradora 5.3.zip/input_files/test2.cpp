#include <iostream>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstring>
#include <string>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <regex>
#include <fstream>
#include "utils.h"
#include "funciones_regex.h"

//Esto es un comentario

using namespace std;

int main() {
    cout << "Hello World!" << endl;
    string word = "test4";
    int num = 5;

}