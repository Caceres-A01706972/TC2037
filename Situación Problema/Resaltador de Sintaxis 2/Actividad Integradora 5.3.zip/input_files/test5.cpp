#include <iostream>
//Esto es un comentario

using namespace std;

int main() {
    cout << "Hello World!" << endl;
    string word = "test5";
    int num = 5;

    const int arraySize = 5;

    string *array;
    array = new string[arraySize];

    return 0;

}