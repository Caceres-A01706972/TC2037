// CPP program to illustrate
// Implementation of clear() function
#include <iostream>
#include <vector>
using namespace std;
  
int main() {

    int i = 0;
    while (i < 5) {
        cout << i << "\n";
        i++;
    }
    // Vector becomes 1, 2, 3, 4, 5
  
    // vector becomes empty
    
    int i=0;
     
    for (i = 1; i <= 10; i++) {
        cout << "Hello World" << endl;   
        if( i == 8){
            break;
        }
    }
    
    return 0;
}